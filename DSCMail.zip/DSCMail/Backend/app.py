from flask import Flask, request, jsonify
from flask_cors import CORS  # Import CORS

app = Flask(__name__)


CORS(app, resources={r"/*": {"origins": "http://localhost:5173"}})

@app.route('/predict-spam', methods=['POST'])
def predict_spam():
    data = request.json
    text = data.get("text", "")

   
    prediction = "spam" 

    return jsonify({"prediction": prediction})

if __name__ == '__main__':
    app.run(debug=True)
