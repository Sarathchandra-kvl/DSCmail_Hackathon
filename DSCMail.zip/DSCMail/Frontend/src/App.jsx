import React from "react";
import EmailInput from "./components/EmailInput";

function App() {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-blue-500 to-purple-600 text-white">
            <h1 className="text-4xl font-bold mb-6">Email Spam Detector 📩</h1>
            <EmailInput />
        </div>
    );
}

export default App;