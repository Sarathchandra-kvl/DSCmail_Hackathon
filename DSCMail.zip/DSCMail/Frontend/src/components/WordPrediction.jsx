import React from "react";

const WordPrediction = ({ predictedWord }) => {
    return (
        <div className="mt-3 p-2 bg-gray-200 text-gray-700 rounded-lg text-sm">
            Suggested word: <span className="font-semibold text-blue-600">{predictedWord}</span>
        </div>
    );
};

export default WordPrediction;
