import React, { useState } from "react";

const EmailInput = () => {
    const [emailText, setEmailText] = useState("");
    const [result, setResult] = useState(null);

    const handleDetectSpam = async () => {
        try {
            const response = await fetch("http://127.0.0.1:5000/predict-spam", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ text: emailText }),
            });
            const data = await response.json();
            setResult(data.result);
        } catch (error) {
            console.error("Error detecting spam:", error);
        }
    };

    return (
        <div className="bg-white shadow-lg rounded-lg p-6 text-black w-96">
            <textarea
                value={emailText}
                onChange={(e) => setEmailText(e.target.value)}
                placeholder="Enter email content..."
                rows={5}
                className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
                onClick={handleDetectSpam}
                className="mt-4 w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300"
            >
                Detect Spam 🚀
            </button>
            {result && <p className="mt-3 text-lg font-semibold">{result}</p>}
        </div>
    );
};

export default EmailInput;
